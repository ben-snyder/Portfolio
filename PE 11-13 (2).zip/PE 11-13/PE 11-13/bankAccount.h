#pragma once
#include <iostream>
#include <string>

//class bankAccount
//{
//public:
//    int num;
//    double bal = 0;
//    void setNum(int), deposit(double), withdraw(double), printInfo();
//    int returnNum();
//    double returnBal();
//    bankAccount(int);
//    bankAccount();
//};
//
//bankAccount::bankAccount(int input)
//{
//    setNum(input);
//}
//
//bankAccount::bankAccount()
//{
//    setNum(0);
//}
//
//void bankAccount::setNum(int input)
//{
//    num = input;
//}
//
//int bankAccount::returnNum()
//{
//    return num;
//}
//
//void bankAccount::deposit(double input)
//{
//    bal = bal + input;
//}
//
//void bankAccount::withdraw(double input)
//{
//    bal = bal - input;
//}
//
//double bankAccount::returnBal()
//{
//    return bal;
//}
//
//void bankAccount::printInfo()
//{
//    cout << "Account Number: " << num << endl
//        << "Balance: " << bal << endl;
//}
//
//class checkingAccount:public bankAccount
//{
//    double interest, minBal, serviceCharge;
//public:
//    void setInterest(double), printInterest(),
//        setMinBal(double), setServiceCharge(double),
//        writeCheck(double), printInfo(), withdraw(double);
//    double returnInterest(), returnMinBal(), returnServiceCharge();
//    bool moreThanMin();
//    checkingAccount(int, double, double, double);
//};
//
//checkingAccount::checkingAccount(int iNum, double iInterest, double iMinBal, double iServiceCharge)
//{
//    setNum(iNum);
//    setInterest(iInterest);
//    setMinBal(iMinBal);
//    setServiceCharge(iServiceCharge);
//}
//
//void checkingAccount::setInterest(double input)
//{
//    interest = input;
//}
//
//double checkingAccount::returnInterest()
//{
//    return interest;
//}
//
//void checkingAccount::printInterest()
//{
//    cout << "Interest Rate: " << interest << endl;
//}
//
//void checkingAccount::setMinBal(double input)
//{
//    minBal = input;
//}
//
//double checkingAccount::returnMinBal()
//{
//    return minBal;
//}
//
//void checkingAccount::setServiceCharge(double input)
//{
//    serviceCharge = input;
//}
//
//double checkingAccount::returnServiceCharge()
//{
//    return serviceCharge;
//}
//
//void checkingAccount::writeCheck(double input)
//{
//    bal = bal - input;
//}
//
//void checkingAccount::printInfo()
//{
//    cout << "Account Number: " << num << endl
//        << "Balance: " << bal << endl
//        << "Interest Rate: " << interest << endl
//        << "Minimum Balance: " << minBal << endl
//        << "Service Charge Cost: " << serviceCharge << endl;
//}
//
//void checkingAccount::withdraw(double input)
//{
//    bal = bal - input;
//}
//
//bool checkingAccount::moreThanMin()
//{
//    if (bal >= minBal)
//        return true;
//    else
//        return false;
//}
//
//class savingsAccount:public bankAccount
//{
//    double interest;
//public:
//    void setInterest(double), printInterest(),
//        withdraw(double), printInfo();
//    double returnInterest();
//    savingsAccount(int, double);
//    savingsAccount(int);
//};
//
//savingsAccount::savingsAccount(int iNum, double iInterest)
//{
//    setNum(iNum);
//    setInterest(iInterest);
//}
//
//savingsAccount::savingsAccount(int iNum)
//{
//    setNum(iNum);
//    setInterest(100);
//}
//
//void savingsAccount::setInterest(double input)
//{
//    interest = input;
//}
//
//double savingsAccount::returnInterest()
//{
//    return interest;
//}
//
//void savingsAccount::printInterest()
//{
//    cout << "Interest Rate: " << interest << endl;
//}
//
//void savingsAccount::withdraw(double input)
//{
//    bal = bal - input;
//}
//
//void savingsAccount::printInfo()
//{
//    cout << "Account Number: " << num << endl
//        << "Balance: " << bal << endl
//        << "Interest Rate: " << interest << endl;
//}