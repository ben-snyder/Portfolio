#include <iostream>
#include <string>
//#include "bankAccount.h"

using namespace std;

class bankAccount
{
public:
    int num;
    double bal = 0;
    void setNum(int), deposit(double), withdraw(double), printInfo();
    int returnNum();
    double returnBal();
    bankAccount(int);
    bankAccount();
};

bankAccount::bankAccount(int input)
{
    setNum(input);
}

bankAccount::bankAccount()
{
    setNum(0);
}

void bankAccount::setNum(int input)
{
    num = input;
}

int bankAccount::returnNum()
{
    return num;
}

void bankAccount::deposit(double input)
{
    bal = bal + input;
}

void bankAccount::withdraw(double input)
{
    bal = bal - input;
}

double bankAccount::returnBal()
{
    return bal;
}

void bankAccount::printInfo()
{
    cout << "Account Number: " << num << endl
        << "Balance: " << bal << endl;
}

class checkingAccount :public bankAccount
{
    double interest, minBal, serviceCharge;
public:
    void setInterest(double), printInterest(),
        setMinBal(double), setServiceCharge(double),
        writeCheck(double), printInfo(), withdraw(double);
    double returnInterest(), returnMinBal(), returnServiceCharge();
    bool moreThanMin();
    checkingAccount(int, double, double, double);
};

checkingAccount::checkingAccount(int iNum, double iInterest, double iMinBal, double iServiceCharge)
{
    setNum(iNum);
    setInterest(iInterest);
    setMinBal(iMinBal);
    setServiceCharge(iServiceCharge);
}

void checkingAccount::setInterest(double input)
{
    interest = input;
}

double checkingAccount::returnInterest()
{
    return interest;
}

void checkingAccount::printInterest()
{
    cout << "Interest Rate: " << interest << endl;
}

void checkingAccount::setMinBal(double input)
{
    minBal = input;
}

double checkingAccount::returnMinBal()
{
    return minBal;
}

void checkingAccount::setServiceCharge(double input)
{
    serviceCharge = input;
}

double checkingAccount::returnServiceCharge()
{
    return serviceCharge;
}

void checkingAccount::writeCheck(double input)
{
    bal = bal - input;
}

void checkingAccount::printInfo()
{
    cout << "Account Number: " << num << endl
        << "Balance: " << bal << endl
        << "Interest Rate: " << interest << endl
        << "Minimum Balance: " << minBal << endl
        << "Service Charge Cost: " << serviceCharge << endl;
}

void checkingAccount::withdraw(double input)
{
    bal = bal - input;
}

bool checkingAccount::moreThanMin()
{
    if (bal >= minBal)
        return true;
    else
        return false;
}

class savingsAccount :public bankAccount
{
    double interest;
public:
    void setInterest(double), printInterest(),
        withdraw(double), printInfo();
    double returnInterest();
    savingsAccount(int, double);
    savingsAccount(int);
};

savingsAccount::savingsAccount(int iNum, double iInterest)
{
    setNum(iNum);
    setInterest(iInterest);
}

savingsAccount::savingsAccount(int iNum)
{
    setNum(iNum);
    setInterest(100);
}

void savingsAccount::setInterest(double input)
{
    interest = input;
}

double savingsAccount::returnInterest()
{
    return interest;
}

void savingsAccount::printInterest()
{
    cout << "Interest Rate: " << interest << endl;
}

void savingsAccount::withdraw(double input)
{
    bal = bal - input;
}

void savingsAccount::printInfo()
{
    cout << "Account Number: " << num << endl
        << "Balance: " << bal << endl
        << "Interest Rate: " << interest << endl;
}

int create(int);
void checkMenu(checkingAccount);
void saveMenu(savingsAccount);

int main()
{
    checkingAccount testCheck(123, .05, 50, 5);
    savingsAccount testSave(456, .1);

    int accountNum = 1, choice;

    //cout << "Create account [1] or go to menu [2]? ";
    //cin >> choice;
    //if (choice == 1)
        accountNum = create(accountNum);
    //else
        //menu();

    return 0;
}

int create(int accountNum)
{
    int choice;
    double interest, minBal, serviceCharge;

    cout << "Create checking account [1] or savings account [2]? ";
    cin >> choice;

    if (choice == 1)
    {
        cout << "Enter interest rate: $";
        cin >> interest;
        cout << "Enter minimum balance: $";
        cin >> minBal;
        cout << "Enter service charge amount: $";
        cin >> serviceCharge;

        checkingAccount tempCheck(accountNum, interest, minBal, serviceCharge);
        checkMenu(tempCheck);
    }
    else
    {
        cout << "Enter interest rate: $";
        cin >> interest;

        savingsAccount tempSave(accountNum, interest);
        saveMenu(tempSave);
    }
    
    return accountNum++;
}

void checkMenu(checkingAccount tempCheck)
{
    int choice;
    cout << "Would you like to..."
        << "\n\t[1] Check balance"
        << "\n\t[2] Deposit"
        << "\n\t[3] Withdraw"
        << "\n\t[4] Exit\n";
    cin >> choice;

    if (choice == 1)
    {
        int cont;
        
        cout << "Current balance: " << tempCheck.returnBal() << "\n";

        cout << "Would you like to continue?"
            << "\n[1] Yes"
            << "\n[2] No\n";
        cin >> cont;
        if (cont == 1)
            checkMenu(tempCheck);
    }
    else if (choice == 2)
    {
        int cont;
        double amount;
        cout << "Enter deposit amount: $";
        cin >> amount;
        tempCheck.deposit(amount);

        cout << "Would you like to continue?"
            << "\n[1] Yes"
            << "\n[2] No\n";
        cin >> cont;
        if (cont == 1)
            checkMenu(tempCheck);
    }
    else if (choice == 3)
    {
        int cont;
        double amount;
        cout << "Enter withdrawal amount: $";
        cin >> amount;
        tempCheck.withdraw(amount);

        cout << "Would you like to continue?"
            << "\n[1] Yes"
            << "\n[2] No\n";
        cin >> cont;
        if (cont == 1)
            checkMenu(tempCheck);
    }
}

void saveMenu(savingsAccount tempSave)
{
    int choice;
    cout << "Would you like to..."
        << "\n\t[1] Check balance"
        << "\n\t[2] Deposit"
        << "\n\t[3] Withdraw"
        << "\n\t[4] Exit\n";
    cin >> choice;

    if (choice == 1)
    {
        int cont;

        cout << "Current balance: " << tempSave.returnBal();

        cout << "Would you like to continue?"
            << "\n[1] Yes"
            << "\n[2] No\n";
        cin >> cont;
        if (cont == 1)
            saveMenu(tempSave);
    }
    else if (choice == 2)
    {
        int cont;
        double amount;
        cout << "Enter deposit amount: $";
        cin >> amount;
        tempSave.deposit(amount);

        cout << "Would you like to continue?"
            << "\n[1] Yes"
            << "\n[2] No\n";
        cin >> cont;
        if (cont == 1)
            saveMenu(tempSave);
    }
    else if (choice == 3)
    {
        int cont;
        double amount;
        cout << "Enter withdrawal amount: $";
        cin >> amount;
        tempSave.withdraw(amount);

        cout << "Would you like to continue?"
            << "\n[1] Yes"
            << "\n[2] No\n";
        cin >> cont;
        if (cont == 1)
            saveMenu(tempSave);
    }
}

