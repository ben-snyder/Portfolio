<?php
require('../model/variables.php');
require('../model/config.php');
require('../model/cubnb_db.php');
include $header;
$reservations = get_reservations();
?>

<div id="master">
    <div id="main-container">
        <h2>Reservation List</h2>
        <br />
        <div id="nav-container-left">
            <!-- display a list of categories -->
            <ul>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
            </ul>
        </div>

        <div id="content">
            <table>
                <thead>
                    <tr>    
                        <th>Reservation ID</th>
                        <th>Customer ID</th>
                        <th>Location ID</th>
                        <th>Admin ID</th>
                        <th>Begin Date</th>
                        <th>End Date</th>
                        <th>Credit Card</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    //var_dump($reservations);
                    $row_count = $reservations->num_rows;

                    for ($i = 0; $i < $row_count; $i++) :
                        $reservation = $reservations->fetch_assoc();
                        ?>
                        <tr>
                            <td><?php echo $reservation['Res_ID']; ?></td>
                            <td><?php echo $reservation['Cust_ID']; ?></td>
                            <td><?php echo $reservation['Loc_ID']; ?></td>
                            <td><?php echo $reservation['Admin_ID']; ?></td>
                            <td><?php echo $reservation['Res_Begin']; ?></td>
                            <td><?php echo $reservation['Res_End']; ?></td>
                            <td><?php echo $reservation['Res_CreditCard']; ?></td>
                        </tr>
                        <?php
                    endfor;
                    ?>
                </tbody>
            </table>
        </div>

        <?php include $footer; ?>
