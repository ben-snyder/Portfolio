<?php
require('../model/variables.php');
require('../model/config.php');
require('../model/cubnb_db.php');
include $header;
$reservation = "";
$customers = get_customers();
$locations = get_locations();
$admins = get_admins();
$last_res_id = (int)get_last_res_id() + 1;
//echo $last_res_id;
$amenities = get_amenities();
$amen_requests = get_amen_requests();

if(isset($_REQUEST['Res_ID']) && isset($_REQUEST['Cust_ID']) && isset($_REQUEST['Loc_ID']) && isset($_REQUEST['Admin_ID'])
        && isset($_REQUEST['Res_Begin']) && isset($_REQUEST['Res_End']) && isset($_REQUEST['Res_CreditCard']) && isset($_REQUEST['Amenity'])){
    
    $_SESSION['Res_ID'] = $_REQUEST['Res_ID'];
    $_SESSION['Cust_ID'] = $_REQUEST['Cust_ID'];
    $_SESSION['Loc_ID'] = $_REQUEST['Loc_ID'];
    $_SESSION['Admin_ID'] = $_REQUEST['Admin_ID'];
    $_SESSION['Res_Begin'] = $_REQUEST['Res_Begin'];
    $_SESSION['Res_End'] = $_REQUEST['Res_End'];
    $_SESSION['Res_CreditCard'] = $_REQUEST['Res_CreditCard'];
    $_SESSION['Amenity'] = $_REQUEST['Amenity'];
    
    $SQL = 'INSERT INTO reservation VALUES("' . $_SESSION['Res_ID'] . '", "' . $_SESSION['Cust_ID'] . '", "' . $_SESSION['Loc_ID'] . '", "' .
            $_SESSION['Admin_ID'] . '", "' . $_SESSION['Res_Begin'] . '", "' . $_SESSION['Res_End'] . '", "' . $_SESSION['Res_CreditCard'] . '")';
    
//    echo $SQL;
//    die;
    
    $SQL2 = 'INSERT INTO amenity_request VALUES("' . $_SESSION['Amenity'] . '", "' . $_SESSION['Res_ID'] . '", "' . $_SESSION['Res_Begin'] . '")';
    
//    echo $SQL2;
//    die;
    
    $db->query($SQL);
    $db->query($SQL2);
    
    header("Location: " . WEB_ROOT . "reservation/reservation_list.php");
}
?>

<div id="master">
    <div id="main-container">
        <h2>Make a Reservation</h2>
        <br />
        <div id="nav-container-left">
            <!-- display a list of categories -->
            <ul>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
                <br></br>
                <br></br>
                <br></br>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
                <br></br>
                <br></br>
                <br></br>
            </ul>
        </div>

        <div id="content">
            <form action="" method="POST">
                <label for="Res_ID">Reservation ID:</label>
                <input name ="Res_ID" type="text" value="<?php echo $last_res_id; ?>" />
                <br></br>
                
                
<!--                &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
                <a href="<?php echo $home ?>construct.php"> 
                    <input name="amenity" type="button" value="Add an Amenity" />
                </a>
                <br></br>-->
                
<!--                <label for="Cust_ID">Customer ID:</label>
                <input name ="Cust_ID" type="text" 
                <?php // if (!($reservation == "")): ?>
                           value="<?php // echo $reservation['Cust_ID']; ?>" readonly="readonly" 
                       <?php // endif; ?>
                       />-->
                <label for="Cust_ID">Customer ID:</label>
                <select name="Cust_ID">
                    <?php
                    $row_count = $customers->num_rows;

                    for ($i = 0; $i < $row_count; $i++) :
                        $customer = $customers->fetch_assoc();
                        ?>

                        <option value="<?php echo $customer['Cust_ID']; ?>"
                        <?php if (!($reservation == "") && $customer['Cust_ID'] == $reservation['Cust_ID']):
                            echo "selected ";
                            ?> 
                                    <?php endif; ?>><?php
                                    echo $customer['Cust_ID']; ?>
                                    </option>

                                    <?php
                                endfor;
                                ?>
                </select>
                <br></br>

<!--                <label for="Loc_ID">Location ID:</label>
                <input name ="Loc_ID" type="text" 
                <?php // if (!($reservation == "")): ?>
                           value="<?php // echo $reservation['Loc_ID']; ?>" readonly="readonly" 
                       <?php // endif; ?>
                       />-->
                <label for="Loc_ID">Location ID:</label>
                <select name="Loc_ID">
                    <?php
                    $row_count = $locations->num_rows;

                    for ($i = 0; $i < $row_count; $i++) :
                        $location = $locations->fetch_assoc();
                        ?>

                        <option value="<?php echo $location['Loc_ID']; ?>"
                        <?php if (!($reservation == "") && $location['Loc_ID'] == $reservation['Loc_ID']):
                            echo "selected ";
                            ?> 
                                    <?php endif; ?>><?php
                                    echo $location['Loc_ID']; ?>
                                    </option>

                                    <?php
                                endfor;
                                ?>
                </select>
                <br></br>
                
                <label for="Admin_ID">Admin ID:</label>
<!--                <input name ="Admin_ID" type="text" 
                <?php // if (!($reservation == "")): ?>
                           value="<?php // echo $reservation['Admin_ID']; ?>" readonly="readonly" 
                       <?php // endif; ?>
                       />-->
                <select name="Admin_ID">
                    <?php
                    $row_count = $admins->num_rows;

                    for ($i = 0; $i < $row_count; $i++) :
                        $admin = $admins->fetch_assoc();
                        ?>

                        <option value="<?php echo $admin['Admin_ID']; ?>"
                        <?php if (!($reservation == "") && $admin['Admin_ID'] == $reservation['Admin_ID']):
                            echo "selected ";
                            ?> 
                                    <?php endif; ?>><?php
                                    echo $admin['Admin_ID']; ?>
                                    </option>

                                    <?php
                                endfor;
                                ?>
                </select>
                <br></br>
                
                <label for="Res_Begin">Start Date:</label>
                <input name ="Res_Begin" type="date" 
                <?php if (!($reservation == "")): ?>
                           value="<?php echo $reservation['Res_Begin']; ?>" readonly="readonly" 
                       <?php endif; ?>
                       />
                <br></br>
                
                <label for="Res_End">End Date:</label>
                <input name ="Res_End" type="date" 
                <?php if (!($reservation == "")): ?>
                           value="<?php echo $reservation['Res_End']; ?>" readonly="readonly" 
                       <?php endif; ?>
                       />
                <br></br>
                
                <label for="Res_CreditCard">Credit Card:</label>
                <input name ="Res_CreditCard" type="text" 
                <?php if (!($reservation == "")): ?>
                           value="<?php echo $reservation['Res_CreditCard']; ?>" readonly="readonly" 
                       <?php endif; ?>
                       />
                <br></br>
                
                <label for="Amenity">Amenity:</label>
                <select name="Amenity">
                    <?php
                    $row_count = $amenities->num_rows;

                    for ($i = 0; $i < $row_count; $i++) :
                        $amenity = $amenities->fetch_assoc();
                        ?>

                        <option value="<?php echo $amenity['Charge_ID']; ?>"
                        <?php if (!($reservation == "")):
                            echo "selected ";
                            ?> 
                                    <?php endif; ?>><?php
                                    echo $amenity['Am_Description']; ?>
                                    </option>

                                    <?php
                                endfor;
                                ?>
                </select>
                <br></br>
                
                
                    <input type="submit" value="Submit" />
<!--                <br><label>Reservation ID<input name="Res_ID" type="text"></label></br>
                <br><label>Customer ID<input name="Cust_ID" type="text"></label></br>
                <br><label>Location ID<input name="Loc_ID" type="text"></label></br>
                <br><label>Admin ID<input name="Admin_ID" type="text"></label></br>
                <br><label>Start Date<input name="Res_Begin" type="text"></label></br>
                <br><label>End Date<input name="Res_End" type="text"></label></br>
                <br><label>Credit Card<input name="Res_CreditCard" type="text"></label></br>
                <br><a href="../reservation/reservation_list.php"><input name="button" type="button" value="Reserve"></a></br>-->
            </form>
        </div>

        <?php include $footer; ?>
