<?php

error_reporting(E_ALL & ~E_NOTICE);
require('../model/config.php');
require('../model/variables.php');
require('../model/cubnb_db.php');
$users = get_users();

if (isset($_POST['action']))
{
    $action = $_POST['action'];
}
else if (isset($_GET['action']))
{
    $action = $_GET['action'];
}
else
{
    $action = 'display';
}
if ($action == 'display')
{
    include('user_list.php');
}
else if ($action == 'show_add_form')
{
    $user = "";
    include('user_add_edit.php');
}
else if ($action == 'show_edit_form')
{
    if (isset($_GET['user_id']))
    {
        $UserID = $_GET['user_id'];
    }
    else if (isset($_POST['user_id']))
    {
        $UserID = $_POST['user_id'];
    }
    else
    {
        $UserID = '';
    }
    $user = get_user($UserID);
    include('user_add_edit.php');
}
else if ($action == 'delete_user')
{
    // Validate the inputs
    $error = "";

    if (isset($_POST['user_id']))
    {
        $UserID = $_POST['user_id'];
        // if there are other files in which user is referenced, do not allow
//        if (get_reservation_count_by_sailor($SID) > 0)
//        {
//            $error = "Sailor ID is used in a reservation.";
//        }
    }
    else
    {
        $error = "User ID";
    }

    if (!(empty($error)))
    {
        $error = "Invalid user data. (" . $error . ")";
        include('../errors/error.php');
    }
    else
    {
        delete_user($UserID);
        header('Location: index.php');
    }
}
else if ($action == 'add_user')
{
    $error = '';

    if (isset($_POST['user_id']))
    {
        $UserID = $_POST['user_id'];
        if (empty($UserID))
        {
            $error = "User ID";
        }
    }
    else
    {
        $error = "User ID";
    }

    if (isset($_POST['password']))
    {
        $Password = $_POST['password'];
        if (empty($Password))
        {
            $error = "Password";
        }
        else
        {
            $Password = generateHash($Password);
        }
    }
    else
    {
        $error = "Password";
    }

    if (isset($_POST['user_lname']))
    {
        $UserLName = $_POST['user_lname'];
        if (empty($UserLName))
        {
            $error = "Last Name";
        }
    }
    else
    {
        $error = "Last Name";
    }

    if (isset($_POST['user_fname']))
    {
        $UserFName = $_POST['user_fname'];
        if (empty($UserFName))
        {
            $error = "First Name";
        }
    }
    else
    {
        $error = "First Name";
    }
    
    // Validate the inputs
    if (!(empty($error)))
    {
        $error = "Invalid user data. (" . $error . ")";
        include('../errors/error.php');
    }
    else
    {
        add_user($UserID, $Password, $UserLName, $UserFName);
        header('Location: index.php');
    }
}
else if ($action == 'update_sailor')
{
    $error = '';

    if (isset($_POST['user_id']))
    {
        $UserID = $_POST['user_id'];
        if (empty($UserID))
        {
            $error = "User ID";
        }
    }
    else
    {
        $error = "User ID";
    }

    if (isset($_POST['password']))
    {
        $Password = $_POST['password'];
        if (empty($Password))
        {
            $error = "Password";
        }
        else
        {
            $Password = generateHash($Password);
        }
    }
    else
    {
        $error = "Password";
    }

    if (isset($_POST['user_lname']))
    {
        $UserLName = $_POST['user_lname'];
        if (empty($UserLName))
        {
            $error = "Last Name";
        }
    }
    else
    {
        $error = "Last Name";
    }

    if (isset($_POST['user_fname']))
    {
        $UserFName = $_POST['user_fname'];
        if (empty($UserFName))
        {
            $error = "First Name";
        }
    }
    else
    {
        $error = "First Name";
    }

    // Validate the inputs
    if (!(empty($error)))
    {
        $error = "Invalid user data. (" . $error . ")";
        include('../errors/error.php');
    }
    else
    {
        update_sailor($UserID, $Password, $UserLName, $UserFName);
        header('Location: index.php');
    }
}
?>