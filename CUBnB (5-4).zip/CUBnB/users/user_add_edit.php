<?php include $header; ?>

<div id="master">
    <div id="main-container">

        <?php
        if ($user == '')
        {
            $heading_text = "Add User";
        }
        else
        {
            $heading_text = "Edit User";
        }
        ?>
        <h2>Users - <?php echo $heading_text; ?></h2>
        <br />

        <div id="nav-container-left">
            <ul>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
            </ul>
        </div>
        <div id ="content">

            <form action="index.php" method="post" id="add_edit_user_form">            

                <?php if ($user == '') : ?>
                    <input type="hidden" name="action" value="add_user" />
<?php else: ?>
                    <input type="hidden" name="action" value="update_user" />
                    <input type="hidden" name="user_id"
                           value="<?php echo $user['UserID']; ?>" />
<?php endif; ?>

                <label for="User">User ID:</label>
                <input name ="user_id" type="text" STYLE="background-color: yellow" 
                       <?php if (!($user == "")): ?>
                           value="<?php echo $user['UserID']; ?>" readonly="readonly" 
<?php endif; ?>
                       />
                <label>(yellow = req'd)</label>
                <br />
                
                <label for="Password">Password:</label>
                <input name ="password" type="text" STYLE="background-color: yellow" 
                       <?php if (!($user == "")): ?>
                           value="<?php echo $user['Password']; ?>" 
<?php endif; ?>
                       />
                <label>(yellow = req'd)</label>
                <br />
                
                <label for="user_lname">Last Name:</label>
                <input name ="user_lname" type="text" STYLE="background-color: yellow" 
                       <?php if (!($user == "")): ?>
                           value="<?php echo $user['UserLName']; ?>" 
<?php endif; ?>
                       />
                <label>(yellow = req'd)</label>
                <br />
                
                <label for="user_fname">First Name:</label>
                <input name ="user_fname" type="text" STYLE="background-color: yellow" 
                       <?php if (!($user == "")): ?>
                           value="<?php echo $user['UserFName']; ?>" 
<?php endif; ?>
                       />
                <label>(yellow = req'd)</label>
                <br />
                
                <label>&nbsp;</label>
                <input type="submit" value="Add User" />
                <a href="?action=display">Cancel</a>
                <br />  
                <br />
            </form>
        </div>
    </div>

<?php include $footer; ?>