<?php
require('../model/variables.php');
require('../model/config.php');
require('../model/cubnb_db.php');
include $header;
$users = get_users();
?>

<div id="master">
    <div id="main-container">
        <h2>User List</h2>
        <br />
        <div id="nav-container-left">
            <!-- display a list of categories -->
            <ul>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
            </ul>
        </div>

        <div id="content">
            <table>
                <thead>
                    <tr>    
                        <th>User ID</th>
                        <th>Password</th>
                        <th>Last Name</th>
                        <th>First Name</th>
                        <th>Role</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    //var_dump($reservations);
                    $row_count = $users->num_rows;

                    for ($i = 0; $i < $row_count; $i++) :
                        $user = $users->fetch_assoc();
                        ?>
                        <tr>
                            <td><?php echo $user['UserID']; ?></td>
                            <td><?php echo $user['Password']; ?></td>
                            <td><?php echo $user['UserLName']; ?></td>
                            <td><?php echo $user['UserFName']; ?></td>
                            <td><?php echo $user['UserRole']; ?></td>
                        </tr>
                        <?php
                    endfor;
                    ?>
                </tbody>
            </table>
        </div>

        <?php include $footer; ?>
