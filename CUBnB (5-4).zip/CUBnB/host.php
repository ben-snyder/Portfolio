<?php
require('model/variables.php');
require('model/config.php');
require('model/cubnb_db.php');
include $header;
?>

<div id="master">
    <div id="main-container">
        <h2>Register a Locale</h2>
        <br />
        <div id="nav-container-left">
            <!-- display a list of categories -->
            <ul>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
                <br></br>
                <br></br>
                <br></br>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
                <br></br>
                <br></br>
                <br></br>
            </ul>
        </div>

        <div id="content">
            <form>
                <br><label>Address<input name="address" type="text"></label></br>
                <br><label>Rate<input name="rate" type="text"></label></br>
                <br><label>Description<input name="desc" type="text"></label></br>
                <br><label>Images<input name="images" type="text"></label></br>
                <br><input name="button" type="button" value="Register"></br>
            </form>
        </div>

        <?php include $footer; ?>
