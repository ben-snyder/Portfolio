<?php
require('model/variables.php');
require('model/config.php');
require('model/cubnb_db.php');
include $header;
?>

<div id="master">
    <div id="main-container">
        <h2>This page is under construction.</h2>
        <br />
        <div id="nav-container-left">
            <!-- display a list of categories -->
            <ul>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
            </ul>
        </div>

        <div id="content">
            
        </div>

        <?php include $footer; ?>
