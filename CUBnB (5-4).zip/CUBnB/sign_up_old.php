<?php
require('model/variables.php');
require('model/config.php');
require('model/cubnb_db.php');
include $header;
?>

<div id="master">
    <div id="main-container">
        <h2>Log In</h2>
        <br />
        <div id="nav-container-left">
            <!-- display a list of categories -->
            <ul>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
            </ul>
        </div>

        <div id="content">
            <form>
                <br><input name="fname" type="text" value="First Name"></br>
                <br><input name="lname" type="text" value="Last Name"></br>
                <br><input name="email" type="text" value="Email"></br>
                <br><input name="password" type="text" value="Password"></br>
                <br><input name="phone" type="text" value="Phone Number"></br>
                <br><input name="credit" type="text" value="Credit Card"></br>
                <br><input name="address" type="text" value="Address"></br>
                <br><input name="button" type="button" value="Sign Up"></br>
            </form>
        </div>

        <?php include $footer; ?>
