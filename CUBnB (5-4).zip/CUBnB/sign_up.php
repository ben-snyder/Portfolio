<?php
require('model/variables.php');
require('model/config.php');
require('model/cubnb_db.php');

session_start();

if (isset($_REQUEST['UserID']) && isset($_REQUEST['Password']) && isset($_REQUEST['UserLName']) && isset($_REQUEST['UserFName']) && isset($_REQUEST['UserRole'])) {
    //set session variables
    
    $_SESSION['UserID'] = $_REQUEST['UserID'];
    $_SESSION['Password'] = $_REQUEST['Password'];
    $_SESSION['UserLName'] = $_REQUEST['UserLName'];
    $_SESSION['UserFName'] = $_REQUEST['UserFName'];
    $_SESSION['UserRole'] = $_REQUEST['UserRole'];
    
    add_user($_SESSION['UserID'], $_SESSION['Password'], $_SESSION['UserLName'], $_SESSION['UserFName'], $_SESSION['UserRole']);
    
//    $SQL = 'INSERT INTO user1 VALUES("' . $_SESSION['UserID'] . '", "' . $_SESSION['Password'] . '", "' .
//            $_SESSION['UserLName'] . '", "' . $_SESSION['UserFName'] . '", "' . $_SESSION['UserRole'] . '")';
//    $result = $db->query($SQL);
    
    header("Location: " . WEB_ROOT . "index.php");
    
//    $_SESSION['userid'] = $_REQUEST['UserID'];
//    $_SESSION['password'] = $_REQUEST['Password'];
//
//    $SQL = 'SELECT * FROM user1 WHERE UserID = '
//            . '"' . $_SESSION['userid'] . '"';
//
//    $result = $db->query($SQL);
//    $row_cnt = $result->num_rows;
//    $result = mysqli_fetch_array($result);
    //var_dump($result);

//    if ($row_cnt == 1) {
//        //$checkpass = generateHash($_SESSION['password']);
//        if (verify($_SESSION['password'], $result['Password'])) {
//
////        $_SESSION['role'] = $result[0]; // set user's role
////
////        switch ($_SESSION['role']) {
////            case 'ADMIN' :
////                //possibly re-direct user based on role
////                break;
////            case 'HOUSE' :
////                //possibly re-direct user based on role
////                break;
////        }
//            //$_SESSION['UserFName'];
//            header("Location: http://localhost/CUBnB/index.php");
//        } else {
//            //TERMINATE user's session if logon fails
//            echo "Invalid User ID and/or Password!";
//            unset($_SESSION['userid']);
//            unset($_SESSION['password']);
//            session_destroy();
//        }
//    } else {
//        //TERMINATE user's session if logon fails
//        echo "Invalid User ID and/or Password!";
//        unset($_SESSION['userid']);
//        unset($_SESSION['password']);
//        session_destroy();
//    }
}
?>

<head>
    <title>CU BnB</title>
    <link rel="stylesheet" type="text/css" href="<?php echo "$home"; ?>main.css" />
</head>
<body>

    <div id="master">
        <div id="main-container">

            <form name="logon" action="" method="GET">
                <fieldset>
                    <legend><strong>Create Account</strong></legend></br>
                    <div id ="fieldgrid">
                        <div id="row">
                            <div id="fieldlabel"><label for="UserID"><strong>User ID</strong></label>
                            </div>
                            <div id="fieldcontent"><input type="text" name="UserID" value="" size="8" id="UserID" />
                            </div>
                        </div>
                        <div id="row">
                            <div id="fieldlabel"><label for="Password"><strong>Password</strong></label>
                            </div>
                            <div id="fieldcontent"><input type="password" name="Password" value="" size="20" id="Password" />
                            </div>
                        </div>
                        <div id="row">
                            <div id="fieldlabel"><label for="UserLName"><strong>Last Name</strong></label>
                            </div>
                            <div id="fieldcontent"><input type="text" name="UserLName" value="" id="UserLName" />
                            </div>
                        </div>
                        <div id="row">
                            <div id="fieldlabel"><label for="UserFName"><strong>First Name</strong></label>
                            </div>
                            <div id="fieldcontent"><input type="text" name="UserFName" value="" id="UserFName" />
                            </div>
                        </div>
                        <div id="row">
                            <div id="fieldlabel"><label for="UserRole"><strong>Role</strong></label>
                            </div>
                            <div id="fieldcontent"><input type="text" name="UserRole" value="" id="UserRole" />
                            </div>
                        </div>
                    </div>
                    </br>
                    <div id="buttongrid">
                        <div id="row">
                            <div id="buttoncell" align="right"><input type="submit" value="Sign Up" name="submit"/>
                            </div>
                        </div>
                    </div>
                </fieldset>
            </form>
            </body>

