<?php

function get_reservations()
{
    global $db;
    $query = "SELECT * FROM reservation";
    $result = $db->query($query);
    return $result;
}

function get_customers()
{
    global $db;
    $query = "SELECT * FROM customer";
    $result = $db->query($query);
    return $result;
}

function get_users()
{
    global $db;
    $query = "SELECT * FROM user1";
    $result = $db->query($query);
    return $result;
}

function get_locations()
{
    global $db;
    $query = "SELECT * FROM location";
    $result = $db->query($query);
    return $result;
}

function get_providers()
{
    global $db;
    $query = "SELECT * FROM provider";
    $result = $db->query($query);
    return $result;
}

function get_admins()
{
    global $db;
    $query = "SELECT * FROM admin";
    $result = $db->query($query);
    return $result;
}

function get_amenities()
{
    global $db;
    $query = "SELECT * FROM amenity";
    $result = $db->query($query);
    return $result;
}

function get_amen_requests()
{
    global $db;
    $query = "SELECT * FROM amenity_request";
    $result = $db->query($query);
    return $result;
}

function get_last_res_id()
{
    global $db;
    $query = "SELECT MAX(Res_ID) FROM reservation";
    $result = $db->query($query);
    $result = mysqli_fetch_array($result);
    $result = $result['MAX(Res_ID)'];
    
//    var_dump($result);
//    die;
    
    return $result;
}

function verify($password, $hashedPassword) {
    return crypt($password, $hashedPassword) == $hashedPassword;
    //return $checkPassword == $storedPassword;
}

function add_user($UserID, $Password, $UserLName, $UserFName, $UserRole)
{
    global $db;
    $encryptedPass = generateHash($Password);
    $query = "INSERT INTO user1 VALUES('$UserID', '$encryptedPass', '$UserLName', '$UserFName', '$UserRole')";
    mysqli_query($db, $query);
}

function generateHash($Password)
{
    if (defined("CRYPT_BLOWFISH") && CRYPT_BLOWFISH)
    {
        $salt = '2y$11$' . substr(md5(uniqid(rand(), true)), 0, 22);
        return crypt($Password, $salt);
    }
}