<?php
define('PROJECT_ROOT', 'c:\xampp\htdocs\CUBnB');
define('WEB_ROOT', 'http://localhost/CUBnB/');
$header = PROJECT_ROOT . '\view\header.php';
$footer = PROJECT_ROOT . '\view\footer.php';
$home = WEB_ROOT;
//$logo = WEB_ROOT . 'images/spirit_full_converted.jpg';
?>
