</div>
</div>

<p class ="copyright" align="right">
    &copy; <?php echo date("Y"); ?> Cornerstone University
</p>
</body>

</html>
