<!DOCTYPE html>
<html>
    <head>
        <title>CU BnB</title>
        <link rel="stylesheet" type="text/css"
              href="<?php echo "$home"; ?>main.css" />
    </head>
    <script type="text/javascript">
        function myFunction() 
        {
            var x = document.getElementById("myTopnav");
            if (x.className === "topnav") {
                x.className += " responsive";
            } else {
                x.className = "topnav";
            }
        }
    </script>

    <body>

        <div id="master">

            <h1>CU BnB
<!--                <img 
                    border="0"
                    align="right"
                    margin="50"
                    src="<?php echo $logo; ?>"
                    alt="Cornerstone Eagle Logo"
                    height="90"
                    width="50">-->
            </h1>
            <br></br>

<!--            <div id="nav-container-top">
                <ul>
                    <li><a href="<?php //echo $home; ?>">Home</a></li>
                    <li><a href="<?php //echo $home; ?>/reservations/?action=display">Reservations</a></li>
                    <li><a href="<?php //echo $home; ?>/sailors/">Sailors</a></li>
                    <li><a href="http://www.google.com">Exit</a></li>
                </ul>
            </div> end div nav-container-top 
            -->
            <!--Add Javascript functionality-->
            <div class="topnav" id="myTopnav">
                <a href="<?php echo $home; ?>">Home</a>
<!--                <a href="<?php //echo $home; ?>/sign_in.php">Sign In</a>
                <a href="<?php //echo $home; ?>/sign_up.php">Sign Up</a>-->
                <a href="<?php echo $home; ?>/admin.php">Admin</a>
                <a href="<?php echo $home; ?>construct.php">Bill</a>
                <a href="http://www.google.com">Exit</a>
                <a href="javascript:void(0);" class="icon" onclick="myFunction()">&#9776;</a>
            </div>
            <!--End add JS-->
        </div><!-- end div master -->
        
        <?php session_start(); ?>

