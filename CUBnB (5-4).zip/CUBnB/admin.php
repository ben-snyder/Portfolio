<?php
require('model/variables.php');
require('model/config.php');
require('model/cubnb_db.php');
include $header;
?>

<div id="master">
    <div id="main-container">
        <h2>Administrative View</h2>
        <br />
        <div id="nav-container-left">
            <!-- display a list of categories -->
            <ul>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
            </ul>
        </div>

        <div id="content">
            <form>
                <br><a href="reservation/reservation_list.php"><input name="button" type="button" value="Display Reservations"></a></br>
                <br><a href="customer_list.php"><input name="button" type="button" value="Display Customers"></a></br>
                <br><a href="provider_list.php"><input name="button" type="button" value="Display Providers"></a></br>
                <br><a href="users/user_list.php"><input name="button" type="button" value="Display Users"></a></br>
                <br><a href="construct.php"><input name="button" type="button" value="Display Locations"></a></br>
                <br><a href="amen_request_list.php"><input name="button" type="button" value="Display Amenity Requests"></a></br>
            </form>
        </div>

        <?php include $footer; ?>
