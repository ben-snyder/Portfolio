<?php
require('model/variables.php');
require('model/config.php');
require('model/cubnb_db.php');
include $header;
$providers = get_providers();
?>

<div id="master">
    <div id="main-container">
        <h2>Provider List</h2>
        <br />
        <div id="nav-container-left">
            <!-- display a list of categories -->
            <ul>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
            </ul>
        </div>

        <div id="content">
            <table>
                <thead>
                    <tr>    
                        <th>Provider ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Phone</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    //var_dump($reservations);
                    $row_count = $providers->num_rows;

                    for ($i = 0; $i < $row_count; $i++) :
                        $provider = $providers->fetch_assoc();
                        ?>
                        <tr>
                            <td><?php echo $provider['Pro_ID']; ?></td>
                            <td><?php echo $provider['Pro_FName']; ?></td>
                            <td><?php echo $provider['Pro_LName']; ?></td>
                            <td><?php echo $provider['Pro_Phone']; ?></td>
                        </tr>
                        <?php
                    endfor;
                    ?>
                </tbody>
            </table>
        </div>

        <?php include $footer; ?>
