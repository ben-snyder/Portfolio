<?php
require('model/variables.php');
require('model/config.php');
require('model/cubnb_db.php');
include $header;
$customers = get_customers();
?>

<div id="master">
    <div id="main-container">
        <h2>Customer List</h2>
        <br />
        <div id="nav-container-left">
            <!-- display a list of categories -->
            <ul>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
            </ul>
        </div>

        <div id="content">
            <table>
                <thead>
                    <tr>    
                        <th>Customer ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>Phone</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    //var_dump($reservations);
                    $row_count = $customers->num_rows;

                    for ($i = 0; $i < $row_count; $i++) :
                        $customer = $customers->fetch_assoc();
                        ?>
                        <tr>
                            <td><?php echo $customer['Cust_ID']; ?></td>
                            <td><?php echo $customer['Cust_FName']; ?></td>
                            <td><?php echo $customer['Cust_LName']; ?></td>
                            <td><?php echo $customer['Cust_Address']; ?></td>
                            <td><?php echo $customer['Cust_City']; ?></td>
                            <td><?php echo $customer['Cust_Phone']; ?></td>
                        </tr>
                        <?php
                    endfor;
                    ?>
                </tbody>
            </table>
        </div>

        <?php include $footer; ?>
