<?php
require('model/variables.php');
require('model/config.php');
require('model/cubnb_db.php');
include $header;
?>

<div id="master">
    <div id="main-container">
        <h2>Welcome to CU's BnB!</h2>
        <br />
        <div id="nav-container-left">
            <!-- display a list of categories -->
            <ul>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
            </ul>
        </div>

        <div id="content">
            <?php //echo "Welcome, " . _SESSION['UserFName']; ?>
            
            <h3><a href="reservation/make_reservation.php">Make a Reservation</a></h3>
            <h3><a href="host.php">Host a Locale</a></h3>
        </div>

        <?php include $footer; ?>
