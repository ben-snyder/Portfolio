<?php
require('model/variables.php');
require('model/config.php');
require('model/cubnb_db.php');
include $header;
$requests = get_amen_requests();
?>

<div id="master">
    <div id="main-container">
        <h2>Customer List</h2>
        <br />
        <div id="nav-container-left">
            <!-- display a list of categories -->
            <ul>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
            </ul>
        </div>

        <div id="content">
            <table>
                <thead>
                    <tr>    
                        <th>Charge ID</th>
                        <th>Reservation ID</th>
                        <th>Request Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    //var_dump($reservations);
                    $row_count = $requests->num_rows;

                    for ($i = 0; $i < $row_count; $i++) :
                        $request = $requests->fetch_assoc();
                        ?>
                        <tr>
                            <td><?php echo $request['Charge_ID']; ?></td>
                            <td><?php echo $request['Res_ID']; ?></td>
                            <td><?php echo $request['RequestDate']; ?></td>
                        </tr>
                        <?php
                    endfor;
                    ?>
                </tbody>
            </table>
        </div>

        <?php include $footer; ?>
