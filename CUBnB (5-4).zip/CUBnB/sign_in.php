<?php
require('model/variables.php');
require('model/config.php');
require('model/cubnb_db.php');
include $header;
?>

<div id="master">
    <div id="main-container">
        <h2>Log In</h2>
        <br />
        <div id="nav-container-left">
            <!-- display a list of categories -->
            <ul>
                <br></br>
                <br></br>
                <br></br>
                <br></br>                
                <br></br>
                <br></br>
                <br></br>
            </ul>
        </div>

        <div id="content">
            <form>
                <br><label>Email<input name="email" type="text"></label></br>
                <br><label>Password<input name="password" type="text"></label></br>
                <br><input name="button" type="button" value="Sign In"></br>
            </form>
        </div>
    

        <?php include $footer; ?>
