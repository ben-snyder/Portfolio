﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;

namespace Retry_Final_Project
{
    public partial class Form1 : Form
    {
        static double p1 = 75.00;
        static double p2 = 80.00;
        static double p3 = 105.00;
        static double p4 = 79.95;
        string record;
        double total;
        string everything;

        PrintDocument doc = new PrintDocument();
        PrintDialog dia = new PrintDialog();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //cb1.Items.Add(string.Format("{0, -20} {1, 5}", "Sprinters High", p1.ToString("f2")));
            //cb1.Items.Add(string.Format("{0, -20} {1, 5}", "Sprint In Style", p2.ToString("f2")));
            //cb1.Items.Add(string.Format("{0, -20} {1, 5}", "Marathon Madness", p3.ToString("f2")));
            //cb1.Items.Add(string.Format("{0, -20} {1, 5}", "Marathon Munchie", p4.ToString("f2")));

            cb1.Items.Add("Sprinters High".PadRight(20) + p1.ToString("f2"));
            cb1.Items.Add("Sprint In Style".PadRight(20) + p2.ToString("f2"));
            cb1.Items.Add("Marathon Madness".PadRight(19) + p3.ToString("f2"));
            cb1.Items.Add("Marathon Munchie".PadRight(20) + p4.ToString("f2"));
        }

        private void cb1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string[] thing = cb1.Text.Split(' ');
            total += Convert.ToDouble(thing[thing.Length - 1]);
            record += cb1.Text + "\n";
            lblSelected.Text = cb1.Text;
            everything = record + "\nTotal".PadRight(20) + total.ToString("f2");
            lblTotal.Text = everything;
        }

        private void lblSelected_Click(object sender, EventArgs e)
        {

        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            doc.DocumentName = "Show Receipt";
            dia.Document = doc;

            doc.PrintPage += delegate (object sender1, PrintPageEventArgs e1)
            {
                e1.Graphics.DrawString(("Running Rocco's\n\n" + everything), new Font("Times New Roman", 12),
                    new SolidBrush(Color.Black),
                    new RectangleF(0, 0, doc.DefaultPageSettings.PrintableArea.Width,
                    doc.DefaultPageSettings.PrintableArea.Height));
            };
            try
            {
                if (dia.ShowDialog() == DialogResult.OK)
                {
                    doc.Print();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Exception occured while printing", ex);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            cb1.Text = "";
            cb1.Focus();
            lblSelected.Text = null;
            lblTotal.Text = null;
            total = 0;
            record = null;
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            PrintPreviewDialog pre = new PrintPreviewDialog();
            pre.Document = doc;
            pre.ShowDialog();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
