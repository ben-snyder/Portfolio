#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <sstream>

using namespace std;

int main()
{
    ifstream inData;
    ofstream outData;
    inData.open("data.txt");
    outData.open("output.txt");

    const int length = 20;
    string arr[length];
    int score1 = 0;

    for (int i = 0; i < length; i++)
    {
        inData >> arr[i];
    }

    for (int i = 0; i < 16; i = i + 2)
    {
        score1 = score1 + calc(arr[i], arr[(i + 1)], arr[(i + 2)], arr[i + 3], arr[(i + 4)]);
    }

    score1 = score1 + calc(arr[(length - 4)], arr[(length - 3)], arr[(length - 2)], arr[(length - 1)], "~");
    score1 = score1 + calc(arr[(length - 2)], arr[(length - 2)], "~", "~", "~");

    return 0;
}

int calc(string f1r1, string f1r2, string f2r1, string f2r2, string f3r1)
{
    int score = 0;

    if (f1r1 != "X" && f1r2 != "/")
        score = score + stoi(f1r1) + stoi(f1r2);
    else if (f1r1 == "X")
    {
        if (f2r1 != "X" && f2r2 != "/")
            score = score + 10 + stoi(f2r1) + stoi(f2r2);
        else if (f2r1 == "X")
            if (f3r1 == "X")
                score = score + 30;
            else
                score = score + 20 + stoi(f3r1);
        else if (f2r2 == "/")
            score = score + 20 + stoi(f2r1);
    }
    else if (f1r2 == "/")
    {
        if (f2r1 != "X")
            score = score + 10 + stoi(f2r1);
        else
            score = score + 20;
    }

    return score;
}