﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwapProgram_2
{
    class Program
    {
        public delegate void DoWork(int x, int y);

        static void Main(string[] args)
        {
            int first = 1;
            int second = 2;

            Console.WriteLine(first + " " + second);

            DoWork del1 = new DoWork(Swap);
            del1(first, second);

            DoWork del2 = new DoWork(Add);
            del2(first, second);

            Console.WriteLine(first + " " + second);


            Console.ReadLine();
        }

        static void Swap(int a, int b)
        {
            int temp = a;
            a = b;
            b = temp;
            Console.WriteLine(a + " and " + b + " were swapped");
        }

        static void Add(int a, int b)
        {
            int c = a + b;
            Console.WriteLine(a + " and " + b + " were added");
        }
    }
}
