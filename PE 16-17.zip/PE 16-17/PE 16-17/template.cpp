#include <iostream>
#include <string>

using namespace std;

//struct nodeType;
struct nodeType
{
    char info;
    nodeType* link;
};
void rotate(nodeType, nodeType);
bool vowel(char);
void loop(nodeType, nodeType, nodeType);

int main()
{
    nodeType *first = nullptr, *last = nullptr, *newNode, *current;

    string input;
    cout << "Convert to Pig Latin" << endl << "Enter word: ";
    cin >> input;

    for (int i = 0; i < input.length(); i++)
    {
        newNode = new nodeType;
        newNode->info = input[i];
        newNode->link = nullptr;
        if (first == nullptr)
        {
            first = newNode;
            last = newNode;
        }
        else
        {
            last->link = newNode;
            last = newNode;
        }
    }

    current = first;
    while (current != nullptr)
    {
        if (vowel(current->info))
        {
            newNode = new nodeType;
            newNode->info = '-';
            newNode->link = nullptr;
            last->link = newNode;
            last = newNode;

            newNode = new nodeType;
            newNode->info = 'w';
            newNode->link = nullptr;
            last->link = newNode;
            last = newNode;

            newNode = new nodeType;
            newNode->info = 'a';
            newNode->link = nullptr;
            last->link = newNode;
            last = newNode;

            newNode = new nodeType;
            newNode->info = 'y';
            newNode->link = nullptr;
            last->link = newNode;
            last = newNode;
        }
        else
        {
            newNode = new nodeType;
            newNode->info = '-';
            newNode->link = nullptr;
            last->link = newNode;
            last = newNode;


            loop(current, last, newNode);
            /*rotate(current, last);
            if (vowel(current->info))
            {

            }*/
        }
        current = current->link;
    }

    return 0;
}

//struct nodeType
//{
//    char info;
//    nodeType* link;
//};

bool vowel(char ch)
{
    switch (ch)
    {
    case 'a':
    case 'e':
    case 'i':
    case 'o':
    case 'u':
    case 'y':
    case 'A':
    case 'E':
    case 'I':
    case 'O':
    case 'U':
    case 'Y':
        return true;
    default:
        return false;
    }
}

void rotate(nodeType *first, nodeType *last)
{
    last->link = first;
    last = first;
    delete first;
}

void loop(nodeType *current, nodeType *last, nodeType *newNode)
{
    rotate(current, last);
    if (vowel(current->info))
    {
        newNode = new nodeType;
        newNode->info = 'a';
        newNode->link = nullptr;
        last->link = newNode;
        last = newNode;

        newNode = new nodeType;
        newNode->info = 'y';
        newNode->link = nullptr;
        last->link = newNode;
        last = newNode;
    }
    else
    {
        loop(current, last, newNode);
    }
}