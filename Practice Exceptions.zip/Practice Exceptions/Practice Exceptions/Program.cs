﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice_Exceptions
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee[] e_array = new Employee[5];

            for (int i = 0; i < 5; i++)
            {
                try
                {
                    Console.Write("Enter ID number: ");
                    int input1 = Convert.ToInt32(Console.ReadLine());
                    
                    Console.Write("Enter wage: ");
                    double input2 = Convert.ToDouble(Console.ReadLine());

                    e_array[i] = new Employee(input1, input2);
                }
                catch (Argument_Exception)
                {
                    e_array[i] = new Employee(999, 6.00);
                    Console.WriteLine("Invalid input");
                }

                Console.WriteLine();
            }

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine(e_array[i].IDnum + " " + e_array[i].hourly_wage);
            }


            Console.ReadLine();
        }

        public class Argument_Exception : Exception
        {
            public static string msg = "Invalid Argument Exception";
            public Argument_Exception() : base(msg) { }
        }

        public class Employee
        {
            int _IDnum;
            double _hourly_wage;

            public Employee(int a, double b)
            {
                _IDnum = a;
                _hourly_wage = b;

                if (hourly_wage < 6.00 || hourly_wage > 50.00)
                {
                    throw (new Argument_Exception());
                }
            }

            public int IDnum
            {
                get { return _IDnum; }
                set { _IDnum = value; }
            }

            public double hourly_wage
            {
                get { return _hourly_wage; }
                set { _hourly_wage = value; }
            }
        }


    }
}
