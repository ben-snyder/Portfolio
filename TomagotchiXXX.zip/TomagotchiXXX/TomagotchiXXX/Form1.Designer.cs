﻿namespace TomagotchiXXX
{
    partial class Tomagotchi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tomagotchi));
            this.lblName = new System.Windows.Forms.Label();
            this.lblMood = new System.Windows.Forms.Label();
            this.lblHealth = new System.Windows.Forms.Label();
            this.pbMood = new System.Windows.Forms.ProgressBar();
            this.pbHealth = new System.Windows.Forms.ProgressBar();
            this.ilPet = new System.Windows.Forms.ImageList(this.components);
            this.picPet = new System.Windows.Forms.PictureBox();
            this.btnTreat = new System.Windows.Forms.Button();
            this.btnFeed = new System.Windows.Forms.Button();
            this.btnPlay = new System.Windows.Forms.Button();
            this.btnNap = new System.Windows.Forms.Button();
            this.btnMeds = new System.Windows.Forms.Button();
            this.tAging = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.picPet)).BeginInit();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.White;
            this.lblName.Location = new System.Drawing.Point(159, 19);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(159, 37);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Pet Name";
            // 
            // lblMood
            // 
            this.lblMood.AutoSize = true;
            this.lblMood.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMood.ForeColor = System.Drawing.Color.White;
            this.lblMood.Location = new System.Drawing.Point(46, 83);
            this.lblMood.Name = "lblMood";
            this.lblMood.Size = new System.Drawing.Size(53, 20);
            this.lblMood.TabIndex = 1;
            this.lblMood.Text = "Mood:";
            // 
            // lblHealth
            // 
            this.lblHealth.AutoSize = true;
            this.lblHealth.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHealth.ForeColor = System.Drawing.Color.White;
            this.lblHealth.Location = new System.Drawing.Point(39, 130);
            this.lblHealth.Name = "lblHealth";
            this.lblHealth.Size = new System.Drawing.Size(60, 20);
            this.lblHealth.TabIndex = 2;
            this.lblHealth.Text = "Health:";
            // 
            // pbMood
            // 
            this.pbMood.Location = new System.Drawing.Point(121, 80);
            this.pbMood.Name = "pbMood";
            this.pbMood.Size = new System.Drawing.Size(239, 23);
            this.pbMood.TabIndex = 3;
            // 
            // pbHealth
            // 
            this.pbHealth.Location = new System.Drawing.Point(121, 127);
            this.pbHealth.Name = "pbHealth";
            this.pbHealth.Size = new System.Drawing.Size(239, 23);
            this.pbHealth.TabIndex = 4;
            // 
            // ilPet
            // 
            this.ilPet.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilPet.ImageStream")));
            this.ilPet.TransparentColor = System.Drawing.Color.Transparent;
            this.ilPet.Images.SetKeyName(0, "cat1.png");
            this.ilPet.Images.SetKeyName(1, "cat2.png");
            this.ilPet.Images.SetKeyName(2, "cat3.png");
            this.ilPet.Images.SetKeyName(3, "dead.jpg");
            // 
            // picPet
            // 
            this.picPet.Image = ((System.Drawing.Image)(resources.GetObject("picPet.Image")));
            this.picPet.Location = new System.Drawing.Point(192, 193);
            this.picPet.Name = "picPet";
            this.picPet.Size = new System.Drawing.Size(100, 100);
            this.picPet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picPet.TabIndex = 5;
            this.picPet.TabStop = false;
            // 
            // btnTreat
            // 
            this.btnTreat.Location = new System.Drawing.Point(6, 342);
            this.btnTreat.Name = "btnTreat";
            this.btnTreat.Size = new System.Drawing.Size(75, 50);
            this.btnTreat.TabIndex = 6;
            this.btnTreat.Text = "Give a\r\nTreat";
            this.btnTreat.UseVisualStyleBackColor = true;
            this.btnTreat.Click += new System.EventHandler(this.btnTreat_Click);
            // 
            // btnFeed
            // 
            this.btnFeed.Location = new System.Drawing.Point(105, 342);
            this.btnFeed.Name = "btnFeed";
            this.btnFeed.Size = new System.Drawing.Size(75, 50);
            this.btnFeed.TabIndex = 7;
            this.btnFeed.Text = "Feed";
            this.btnFeed.UseVisualStyleBackColor = true;
            this.btnFeed.Click += new System.EventHandler(this.btnFeed_Click);
            // 
            // btnPlay
            // 
            this.btnPlay.Location = new System.Drawing.Point(204, 342);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(75, 50);
            this.btnPlay.TabIndex = 8;
            this.btnPlay.Text = "Play a\r\nGame";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // btnNap
            // 
            this.btnNap.Location = new System.Drawing.Point(303, 342);
            this.btnNap.Name = "btnNap";
            this.btnNap.Size = new System.Drawing.Size(75, 50);
            this.btnNap.TabIndex = 9;
            this.btnNap.Text = "Take a\r\nNap";
            this.btnNap.UseVisualStyleBackColor = true;
            this.btnNap.Click += new System.EventHandler(this.btnNap_Click);
            // 
            // btnMeds
            // 
            this.btnMeds.Location = new System.Drawing.Point(402, 342);
            this.btnMeds.Name = "btnMeds";
            this.btnMeds.Size = new System.Drawing.Size(75, 50);
            this.btnMeds.TabIndex = 10;
            this.btnMeds.Text = "Give\r\nMedicine";
            this.btnMeds.UseVisualStyleBackColor = true;
            this.btnMeds.Click += new System.EventHandler(this.button5_Click);
            // 
            // tAging
            // 
            this.tAging.Interval = 1000;
            this.tAging.Tick += new System.EventHandler(this.tAging_Tick);
            // 
            // Tomagotchi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkRed;
            this.ClientSize = new System.Drawing.Size(484, 461);
            this.Controls.Add(this.btnMeds);
            this.Controls.Add(this.btnNap);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.btnFeed);
            this.Controls.Add(this.btnTreat);
            this.Controls.Add(this.picPet);
            this.Controls.Add(this.pbHealth);
            this.Controls.Add(this.pbMood);
            this.Controls.Add(this.lblHealth);
            this.Controls.Add(this.lblMood);
            this.Controls.Add(this.lblName);
            this.Name = "Tomagotchi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.picPet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblMood;
        private System.Windows.Forms.Label lblHealth;
        private System.Windows.Forms.ProgressBar pbMood;
        private System.Windows.Forms.ProgressBar pbHealth;
        private System.Windows.Forms.ImageList ilPet;
        private System.Windows.Forms.PictureBox picPet;
        private System.Windows.Forms.Button btnTreat;
        private System.Windows.Forms.Button btnFeed;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Button btnNap;
        private System.Windows.Forms.Button btnMeds;
        private System.Windows.Forms.Timer tAging;
    }
}

