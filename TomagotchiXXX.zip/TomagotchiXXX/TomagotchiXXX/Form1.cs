﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TomagotchiXXX
{
    public partial class Tomagotchi : Form
    {
        //temperaments
        pet cat = new pet(75, 75, 100);
        wild_animal wolf = new wild_animal(50, 50, 80);
        bool alive = true;

        public Tomagotchi()
        {
            InitializeComponent();
            get_pet_name();
        }

        //start screen
        public void get_pet_name()
        {
            Form2 name_dialog = new Form2();

            if (name_dialog.ShowDialog(this) == DialogResult.OK)
            {
                this.lblName.Text = name_dialog.tbPetName.Text;
                this.tAging.Enabled = true;
            }
            else
            {
                this.lblName.Text = "Cancelled";
            }
            name_dialog.Dispose();
        }

        //buttons
        private void btnTreat_Click(object sender, EventArgs e)
        {
            cat.give_treat();
        }

        private void btnFeed_Click(object sender, EventArgs e)
        {
            cat.eat_meal();
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            cat.play_game();
        }

        private void btnNap_Click(object sender, EventArgs e)
        {
            cat.sleep();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            cat.medicate();
        }

        //age timer
        private void tAging_Tick(object sender, EventArgs e)
        {
            cat.age_days++;
            cat.mood--;
            cat.hunger = cat.hunger - 2;
            alive = cat.check_pet();
            pbHealth.Value = cat.health;
            pbMood.Value = cat.mood;

            if (!alive)
            {
                tAging.Enabled = false;
                picPet.Image = ilPet.Images[3];
                DialogResult result = MessageBox.Show("Your pet has died, would you like to play again?", "Game Over", MessageBoxButtons.YesNo);
                if (result == DialogResult.No)
                {
                    Environment.Exit(0);
                }
                else if (result == DialogResult.Yes)
                {
                    //wip
                }
            }
            else if (cat.age_years > 2)
            {
                picPet.Image = ilPet.Images[2];
            }
            else if (cat.age_years > 1)
            {
                picPet.Image = ilPet.Images[1];
            }
            else
            {
                picPet.Image = ilPet.Images[0];
            }
        }
    }
}
