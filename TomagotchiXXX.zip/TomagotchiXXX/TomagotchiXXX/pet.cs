﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TomagotchiXXX
{
    class pet
    {
        public int hunger = 75;
        public int mood = 75;
        public int health = 100;

        public int age_years = 0;
        public int age_days = 0;
        public bool awake = true;

        //sickness
        static Random exposure = new Random();
        int germs = exposure.Next(999);

        static Random noise = new Random();
        int disturb = noise.Next(10);

        public pet (int c_hunger, int c_mood, int c_health)
        {
            hunger = c_hunger;
            mood = c_mood;
            health = c_health;
        }

        //Treat
        public void give_treat()
        {
            mood = mood + 5;
            hunger = hunger + 5;
        }

        //Meal
        public void eat_meal()
        {
            mood = mood + 10;
            hunger = hunger + 20;
        }

        //Game
        public void play_game()
        {
            mood = mood + 10;
        }

        public void play_game(string game_name)
        {
            if (game_name == "tag")
            {
                mood += 10;
                health += 2;
            }
        }

        //Meds
        public void medicate()
        {
            health = health + 35;
            mood -= 10;
        }

        //Sleep
        public void sleep()
        {
            awake = false;
            health = health + 10;
            mood = mood + 20;
        }

        //Check
        public bool check_pet()
        {
            //Age
            if (age_days > 25)
            {
                age_years++;
                age_days = 0;
            }

            //Sickness
            if (germs > 750)
            {
                health = health - 35;
            }

            //Sleep
            if (disturb > 5)
            {
                awake = true;
            }

            //hunger
            if (hunger > 100)
            {
                health = health - 10;
                hunger = 100;
            }
            else if (hunger > 75)
            {
                health++;
            }
            else if (hunger > 60)
            {
                mood--;
            }
            else if (hunger > 40)
            {
                mood = mood - 10;
            }
            else
            {
                mood = mood - 20;
                health = health - 5;
            }

            //mood
            if (mood > 100)
            {
                mood = 100;
            }
            else if (mood > 60)
            {
                //You have a very happy pet
            }
            else if (mood > 30)
            {
                //Something is wrong
                health--;
            }
            else if (mood > 0)
            {
                //Your pet is extremely depressed
            }
            else
            {
                mood = 0;
            }

            //health
            if (health > 100)
            {
                health = 100;
            }
            else if (health < 0)
            {
                health = 0;
            }

            //death
            if (health > 0 && mood > 0 && hunger > 0 && age_years < 10)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    //notes
    class wild_animal : pet
    {
        public bool zoo_animal = false;

        public wild_animal(int wmood, int whunger, int whealth) : base (wmood, whunger, whealth)
        {

        }
        public void capture()
        {
            zoo_animal = true;
        }
    }


}
